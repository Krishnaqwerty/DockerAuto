import React from 'react'
import Navbar from '../Navbar'

function Dashboard() {
  return (
    <div>
        <Navbar/>
        <h1>hello this is dashboard</h1>
        <h1>hello this is dashboard</h1>
        <h1>hello this is dashboard</h1>
        
    </div>
  )
}

export default Dashboard