import React from 'react'
import Navbar from '../Navbar'

function gets() {
  return (
    <div>
        <Navbar/>
        <h1>hello this is sget</h1>
        <h1>hello this is gets</h1>
        <h1>hello this is get</h1>
        
    </div>
  )
}

export default gets